//
// Created by Zekun Zhang on 10/30/18.
//

#ifndef HOMEWORK_8_TWODIMENSIONALSHAPE_ZEKUN_H
#define HOMEWORK_8_TWODIMENSIONALSHAPE_ZEKUN_H

#include "Shape_Zekun.h"

class TwoDimensionalShape : public Shape{
public:
    TwoDimensionalShape();
    ~TwoDimensionalShape();
    void print_2D() const;

};


#endif //HOMEWORK_8_TWODIMENSIONALSHAPE_ZEKUN_H
