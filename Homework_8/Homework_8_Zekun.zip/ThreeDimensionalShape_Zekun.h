//
// Created by Zekun Zhang on 10/30/18.
//

#ifndef HOMEWORK_8_THREEDIMENSIONALSHAPE_ZEKUN_H
#define HOMEWORK_8_THREEDIMENSIONALSHAPE_ZEKUN_H

#include "Shape_Zekun.h"

class ThreeDimensionalShape : public Shape {
public:
    ThreeDimensionalShape();
    ~ThreeDimensionalShape();
    void print_3D() const;
};


#endif //HOMEWORK_8_THREEDIMENSIONALSHAPE_ZEKUN_H
